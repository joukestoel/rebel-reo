package sct;

public class Relations {

	public static boolean Reject(Object o) {
		return "reject".equals(o);
	}
	
	public static boolean Accept(Object o) {
		return "accept".equals(o);
	}
}
